import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.daiyoung.R

class CourseAdapter(private val courses: List<Map<String, Any>>) :
    RecyclerView.Adapter<CourseAdapter.ViewHolder>() {

    // ViewHolder ช่วยในการถือความหมายของมุมมอง UI ที่เกี่ยวข้องกับ RecyclerView
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCourseName: TextView = itemView.findViewById(R.id.tvCourseName)
        val tvCourseDescription: TextView = itemView.findViewById(R.id.tvCourseDescription)
    }

    // สร้าง ViewHolder โดยการเติมเต็ม/อัดแน่น XML Layout เข้าสู่ ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate layout XML ที่จะใช้แสดงข้อมูล
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.itemlayout, parent, false)

        // Return view holder instance
        return ViewHolder(view)
    }

    // นี่เป็นสิ่งที่เรียกเพื่อแสดงข้อมูลในตำแหน่งที่กำหนด
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // เอาข้อมูลจากรายการที่ใช้ตามตำแหน่ง (position)
        val course = courses[position]

        // ตั้งค่าข้อมูลเกี่ยวข้องกับ view จาก ViewHolder
        holder.tvCourseName.text = course["name"] as? String // ตั้งชื่อคอร์ส
        holder.tvCourseDescription.text = course["description"] as? String // ตั้งคำอธิบาย
    }

    // Return จำนวนรายการใน data set ที่เราให้ไว้
    override fun getItemCount(): Int {
        return courses.size
    }
}