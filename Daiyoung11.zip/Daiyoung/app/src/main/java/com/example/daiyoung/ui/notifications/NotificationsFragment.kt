package com.example.daiyoung.ui.notifications

import CourseAdapter
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.daiyoung.R
import com.example.daiyoung.Uploadcourse
import com.example.daiyoung.databinding.FragmentNotificationsBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.firestore.FirebaseFirestore

class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!

    private lateinit var courseAdapter: CourseAdapter
    private val courses = mutableListOf<Map<String, Any>>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)

        // ตั้งค่า RecyclerView ใน onCreateView
        setupRecyclerView()

        // ใช้ binding เพื่อเข้าถึงปุ่ม
        binding.uploadcourse.setOnClickListener {
            startActivity(Intent(requireActivity(), Uploadcourse::class.java))
        }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ดึงข้อมูลจาก Firestore
        val sharedPref = activity?.getSharedPreferences("USER_DATA", Context.MODE_PRIVATE)
        val userId = sharedPref?.getString("USER_ID", null)
        if (!userId.isNullOrEmpty()) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(userId)
                .collection("courses")
                .get()
                .addOnSuccessListener { querySnapshot ->
                    courses.clear()
                    for (document in querySnapshot) {
                        courses.add(document.data)
                    }
                    courseAdapter.notifyDataSetChanged()
                }
                .addOnFailureListener { e ->
                    Log.e("Firestore Error", "Error loading data", e)
                }
        }
    }

    private fun setupRecyclerView() {
        courseAdapter = CourseAdapter(courses)
        binding.recyclerview.apply {
            adapter = courseAdapter
            layoutManager = LinearLayoutManager(context)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}