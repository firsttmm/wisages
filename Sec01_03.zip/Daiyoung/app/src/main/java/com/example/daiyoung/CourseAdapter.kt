package com.example.daiyoung

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.bumptech.glide.Glide
import com.example.daiyoung.ui.home.CourseDetailActivity


class CourseAdapter(
    private val courses: List<Map<String, Any>>,
    private val onItemClick: (Map<String, Any>) -> Unit
) : RecyclerView.Adapter<CourseAdapter.ViewHolder>() {

    private var filteredCourses: List<Map<String, Any>> = courses  // รายการที่กรองแล้ว

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCourseName: TextView = itemView.findViewById(R.id.tvCourseName)
        val tvCourseDescription: TextView = itemView.findViewById(R.id.tvCourseDescription)
        var tvCoursePic: ImageView = itemView.findViewById(R.id.CourseImage)
        val tvCourseCategory: TextView = itemView.findViewById(R.id.cmodel_category)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.itemlayout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val course = filteredCourses[position]

        holder.tvCourseName.text = course["name"] as? String ?: "No Name"
        holder.tvCourseDescription.text = course["userId"] as? String ?: "No Description"
        holder.tvCourseCategory.text = course["category"] as? String ?: "No Category"
        holder.tvCoursePic.setImageResource(R.drawable.img)
        holder.itemView.setOnClickListener {
            onItemClick(course)
        }



        // โหลดภาพจาก Base64
        val base64Image = course["image"] as? String
        if (!base64Image.isNullOrEmpty()) {
            try {
                val decodedString = Base64.decode(base64Image, Base64.DEFAULT)
                val decodedBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
                Glide.with(holder.tvCoursePic.context)
                    .load(decodedBitmap)
                    .into(holder.tvCoursePic)
            } catch (e: Exception) {
                // ถ้าแปลงภาพผิดพลาด ให้ใช้ภาพเริ่มต้นแทน
                Glide.with(holder.tvCoursePic.context)
                    .load(R.drawable.img)
                    .into(holder.tvCoursePic)
            }
        } else {
            // ถ้าไม่มีภาพ ให้ใช้ภาพเริ่มต้น
            Glide.with(holder.tvCoursePic.context)
                .load(R.drawable.img)
                .into(holder.tvCoursePic)
        }

        holder.itemView.setOnClickListener {
            onItemClick(course) // ส่งข้อมูลที่กดไป
        }
    }

    override fun getItemCount(): Int {
        return filteredCourses.size
    }

    // ฟังก์ชันสำหรับกรองข้อมูล
    fun filterCourses(query: String) {
        filteredCourses = if (query.isEmpty()) {
            courses
        } else {
            courses.filter { course ->
                val courseName = course["name"]?.toString() ?: ""
                val courseCategory = course["category"]?.toString() ?: ""
                courseName.contains(query, ignoreCase = true) ||
                        courseCategory.contains(query, ignoreCase = true)  // ค้นหาชื่อ + หมวดหมู่
            }
        }
        notifyDataSetChanged()
    }
}
