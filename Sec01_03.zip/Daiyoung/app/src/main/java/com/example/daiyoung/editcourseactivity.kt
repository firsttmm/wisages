package com.example.daiyoung

import android.content.Intent
import android.os.Bundle
import android.text.util.Linkify
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore





class editcourseactivity : AppCompatActivity() {
    private lateinit var firestore: FirebaseFirestore
    private var courseId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_course)
        firestore = FirebaseFirestore.getInstance()
        val courseName = intent.getStringExtra("name")
        val courseDescription = intent.getStringExtra("description")
        val courseCategory = intent.getStringExtra("category")
        val courseTopics = intent.getSerializableExtra("topics") as? List<HashMap<String, String>>

        // Setting up the course details
        findViewById<TextView>(R.id.vCourseName).text = courseName
        findViewById<TextView>(R.id.vCourseDescription).text = courseDescription
        findViewById<TextView>(R.id.vCategory).text = courseCategory

        // Back button functionality
        val backbtn = findViewById<Button>(R.id.courseDetail_back)
        backbtn.setOnClickListener {
            finish()
        }

        // Topics display
        val topicContainer = findViewById<LinearLayout>(R.id.topicsLayout)
        topicContainer.removeAllViews()

        courseTopics?.forEach { topic ->
            val topicView = TextView(this).apply {
                val topicText = "Topic: ${topic["title"]}\nDescription: ${topic["description"]}\nVideo Link: ${topic["videoLink"]}"
                text = topicText
                textSize = 24f
                // Use Linkify to automatically recognize the video link and turn it into a clickable link
                Linkify.addLinks(this, Linkify.WEB_URLS)
            }
            topicContainer.addView(topicView)
        }

        // Edit course button
        findViewById<Button>(R.id.btnDeleteCourse).setOnClickListener {
            firestore.collection("courses").document(courseId!!)
                .delete()
                .addOnSuccessListener {
                    // แสดงข้อความว่าได้ลบคอร์สแล้ว
                    Toast.makeText(this, "Course deleted!", Toast.LENGTH_SHORT).show()

                    // ส่งผลลัพธ์กลับไปที่ Activity หรือ Fragment ก่อนหน้า
                    setResult(RESULT_OK)

                    // ส่ง courseId ที่ถูกลบไปยัง Activity ก่อนหน้า
                    val intent = Intent()
                    intent.putExtra("DELETED_COURSE_ID", courseId)
                    setResult(RESULT_OK, intent)

                    // ปิดหน้าจอและกลับไปหน้าก่อนหน้า
                    finish()
                }
                .addOnFailureListener { e ->
                    Log.e("Firestore Error", "Error deleting course", e)
                    // แสดงข้อความหากการลบล้มเหลว
                    Toast.makeText(this, "Failed to delete course", Toast.LENGTH_SHORT).show()
                }
        }

    }
}


