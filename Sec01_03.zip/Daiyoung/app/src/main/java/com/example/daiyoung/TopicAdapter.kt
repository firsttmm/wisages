package com.example.daiyoung

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TopicsAdapter(private val topics: List<HashMap<String, String>>) : RecyclerView.Adapter<TopicsAdapter.TopicViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TopicViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_edit_course, parent, false)
        return TopicViewHolder(view)
    }

    override fun onBindViewHolder(holder: TopicViewHolder, position: Int) {
        val topic = topics[position]
        holder.bind(topic)
    }

    override fun getItemCount(): Int = topics.size

    inner class TopicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // เปลี่ยนเป็นการอ้างอิงถึง TextView ที่ใช้แสดงชื่อหัวข้อ
        private val tvTopicName: TextView = itemView.findViewById(R.id.ttop)

        fun bind(topic: HashMap<String, String>) {
            tvTopicName.text = topic["name"] // แสดงชื่อหัวข้อจาก HashMap
        }
    }
}
