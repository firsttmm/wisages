package com.example.daiyoung.ui.mycourse

import android.app.Activity.RESULT_OK
import com.example.daiyoung.CourseAdapter
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.daiyoung.Uploadcourse
import com.example.daiyoung.databinding.FragmentNotificationsBinding
import com.example.daiyoung.editcourseactivity

import com.example.daiyoung.ui.home.CourseDetailActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlin.text.get



class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!

    private lateinit var courseAdapter: CourseAdapter
    private val courses = mutableListOf<Map<String, Any>>()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)

        setupRecyclerView()

        // ปุ่มอัปโหลดคอร์ส
        binding.uploadcourse.setOnClickListener {
            startActivity(Intent(requireActivity(), Uploadcourse::class.java))
        }

        return binding.root
    }

//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//        fetchCourses()
//    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ดึงข้อมูลจาก Firestore
        val sharedPref = activity?.getSharedPreferences("USER_DATA", Context.MODE_PRIVATE)
        val userId = sharedPref?.getString("USER_ID", null)
        if (!userId.isNullOrEmpty()) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(userId)
                .collection("courses")
                .get()
                .addOnSuccessListener { querySnapshot ->
                    courses.clear()
                    for (document in querySnapshot) {
                        courses.add(document.data)
                    }
                    courseAdapter.notifyDataSetChanged()
                }
                .addOnFailureListener { e ->
                    Log.e("Firestore Error", "Error loading data", e)
                }
        }
    }

    private fun setupRecyclerView() {
        courseAdapter = CourseAdapter(courses) { course ->
            val intent = Intent(requireContext(), editcourseactivity::class.java).apply {
                putExtra("name", course["name"] as String)
                putExtra("description", course["description"] as String)
                putExtra("category", course["category"] as String)
                putExtra("topics", course["topics"] as ArrayList<HashMap<String, String>>)
                putExtra("makerId", course["userId"] as String)
            }
            startActivity(intent)
        }
        binding.recyclerview.apply {
            adapter = courseAdapter
            layoutManager = LinearLayoutManager(context)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            // ถ้าผลลัพธ์คือการลบคอร์ส
            val deletedCourseId = data?.getStringExtra("DELETED_COURSE_ID")

            // ตอนนี้คุณสามารถรีเฟรชรายการคอร์สได้ โดยการดึงข้อมูลใหม่จาก Firestore
            loadCourses() // ฟังก์ชันนี้จะโหลดคอร์สใหม่จาก Firestore
        }

    }

    private fun loadCourses() {
        val userId = requireActivity()
            .getSharedPreferences("USER_DATA", Context.MODE_PRIVATE)
            .getString("USER_ID", null)

        if (!userId.isNullOrEmpty()) {
            FirebaseFirestore.getInstance()
                .collection("courses")
                .orderBy("name", Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener { querySnapshot ->
                    courses.clear()  // ล้างข้อมูลเก่าออก
                    for (document in querySnapshot) {
                        courses.add(document.data)  // เพิ่มคอร์สที่ดึงมาใหม่
                    }
                    courseAdapter.notifyDataSetChanged()  // อัพเดต RecyclerView
                }
                .addOnFailureListener { e ->
                    Log.e("Firestore Error", "Error loading data", e)
                }
        }
    }
}
