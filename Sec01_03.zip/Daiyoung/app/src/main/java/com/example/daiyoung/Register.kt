package com.example.daiyoung

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckedTextView
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.firestore.FirebaseFirestore

class Register : AppCompatActivity() {
    private lateinit var ptxtEmail: EditText
    private lateinit var ptxtPassword: EditText
    private lateinit var ptxtUsername: EditText
    private lateinit var btnSignUp: Button
    private lateinit var checkTxt: CheckedTextView
    private lateinit var ptxtConPass: EditText
    private lateinit var ptxttel: EditText

    private val db = FirebaseFirestore.getInstance() // Firestore Database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()

        btnSignUp.setOnClickListener {
            val email = ptxtEmail.text.toString().trim()
            val password = ptxtPassword.text.toString().trim()
            val username = ptxtUsername.text.toString().trim()
            val tel = ptxttel.text.toString().trim()
            val conpass = ptxtConPass.text.toString().trim()

            if (email.isEmpty() || password.isEmpty() || username.isEmpty() || tel.isEmpty() || conpass.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else if (password != conpass) {
                Toast.makeText(this, "Password does not match", Toast.LENGTH_SHORT).show()}
            else {
                    registerUser(email, password, username, tel,conpass)
                }
            }


        checkTxt.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
        }
    }

    private fun init() {
        ptxtUsername = findViewById(R.id.username)
        ptxtEmail = findViewById(R.id.sig_ptxt_email)
        ptxtPassword = findViewById(R.id.sig_ptxt_pass)
        btnSignUp = findViewById(R.id.sig_btn_signup)
        checkTxt = findViewById(R.id.sig_checktxt_tologin)
        ptxtConPass = findViewById(R.id.txt_conpass)
        ptxttel = findViewById(R.id.txt_tel)
    }

    private fun registerUser(email: String, password: String, username: String ,tel: String,conpass: String) {
        val userData = hashMapOf(
            "email" to email,
            "password" to password,
            "username" to username,
            "tel" to tel
        )

        db.collection("users").document(username).set(userData)
            .addOnSuccessListener {
                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, Login::class.java))
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}