package com.example.daiyoung.ui.home

import com.example.daiyoung.CourseAdapter
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.daiyoung.databinding.FragmentHomeBinding
import com.google.firebase.firestore.FirebaseFirestore
import android.util.Base64
import android.text.Editable
import android.text.TextWatcher
import androidx.lifecycle.ViewModelProvider
import com.google.firebase.firestore.Query



class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding ?: throw IllegalStateException("Binding is null")

    private lateinit var recyclerView: RecyclerView
    private lateinit var courseAdapter: CourseAdapter
    private val courses = mutableListOf<Map<String, Any>>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        recyclerView = binding.popularCourses
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // ตั้งค่า Adapter
        courseAdapter = CourseAdapter(courses) { course ->
            val intent = Intent(requireContext(), CourseDetailActivity::class.java).apply {
                putExtra("name", course["name"] as String)
                putExtra("description", course["description"] as String)
                putExtra("category", course["category"] as String)
                putExtra("topics", course["topics"] as ArrayList<HashMap<String, String>>)
                putExtra("makerId", course["userId"] as String)
            }
            startActivity(intent)
        }
        recyclerView.adapter = courseAdapter

        loadCourses()
        loadUserName()

        // ค้นหาคอร์สเมื่อผู้ใช้พิมพ์ข้อความ
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                courseAdapter.filterCourses(s.toString()) // กรองข้อมูลตามข้อความที่ป้อน
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        binding.seemore.setOnClickListener {
            val intent = Intent(requireContext(), Category::class.java)
            startActivity(intent)
        }

        return root
    }

    private fun loadCourses() {
        FirebaseFirestore.getInstance()
            .collection("courses")
            .orderBy("name", Query.Direction.ASCENDING)
            .get()
            .addOnSuccessListener { querySnapshot ->
                courses.clear()
                for (document in querySnapshot) {
                    val courseData = document.data
                    // Get the base64 encoded string for the image
                    val base64Image = courseData["image"] as? String

                    base64Image?.let {
                        val decodedString = Base64.decode(it, Base64.DEFAULT)
                        val decodedBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
                        courseData["decodedImage"] = decodedBitmap
                    }

                    courses.add(courseData)
                }
                courseAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Log.e("Firestore Error", "Error loading data", e)
            }
    }

    private fun loadUserName() {
        val userId = requireActivity()
            .getSharedPreferences("USER_DATA", Context.MODE_PRIVATE)
            .getString("USER_ID", null)

        _binding?.let { binding ->
            if (!userId.isNullOrEmpty()) {
                FirebaseFirestore.getInstance().collection("users")
                    .document(userId)
                    .get()
                    .addOnSuccessListener { document ->
                        if (document.exists()) {
                            val username = document.getString("username") ?: "User"
                            binding.txtWelcome.text = "Hello, $username"
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.e("Firestore Error", "Error fetching username", e)
                    }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // ปล่อยค่า binding เพื่อป้องกัน memory leaks
    }
}
