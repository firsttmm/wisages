package com.example.daiyoung.ui.profile

import android.app.Activity
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.daiyoung.Login
import com.example.daiyoung.databinding.FragmentProfileBinding
import com.example.daiyoung.team
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage



import android.graphics.Bitmap

import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val sharedPreferences by lazy { requireActivity().getSharedPreferences("USER_DATA", Context.MODE_PRIVATE) }

    companion object {
        private const val PICK_IMAGE_REQUEST = 1
        private const val IMAGE_FILE_NAME = "profile_image.jpg"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val root: View = binding.root

        loadProfileImage()

        binding.profileImage.setOnClickListener {
            openGallery()
        }

        binding.homeBtnSignout.setOnClickListener {
            sharedPreferences.edit().remove("USER_ID").apply()
            startActivity(Intent(root.context, Login::class.java))
            requireActivity().finish()
        }

        binding.btnTeam.setOnClickListener {
            startActivity(Intent(root.context, team::class.java))
        }

        return root
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            val imageUri: Uri? = data?.data
            if (imageUri != null) {
                saveImageToInternalStorage(imageUri)
                loadProfileImage()
            }
        }
    }

    private fun saveImageToInternalStorage(uri: Uri) {
        try {
            val bitmap = MediaStore.Images.Media.getBitmap(requireContext().contentResolver, uri)
            val file = File(requireContext().filesDir, IMAGE_FILE_NAME)
            val outputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
            outputStream.flush()
            outputStream.close()
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Failed to save image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadProfileImage() {
        val file = File(requireContext().filesDir, IMAGE_FILE_NAME)
        if (file.exists()) {
            Glide.with(this).load(file).into(binding.profileImage)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
