package com.example.daiyoung.ui.home

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.daiyoung.R
import com.google.firebase.firestore.FirebaseFirestore
import android.text.util.Linkify

class CourseDetailActivity : AppCompatActivity() {
    private lateinit var firestoreRef: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_detail)
        firestoreRef = FirebaseFirestore.getInstance()
        val userId = getSharedPreferences("app_prefs", MODE_PRIVATE).getString("USER_ID", null)
        val courseName = intent.getStringExtra("name")
        val courseDescription = intent.getStringExtra("description")
        val courseCategory = intent.getStringExtra("category")
        val courseTopics = intent.getSerializableExtra("topics") as? List<HashMap<String, String>>
        val courseMakerId = intent.getStringExtra("makerId")

        findViewById<TextView>(R.id.tvCourseName).text = courseName
        findViewById<TextView>(R.id.tvCourseDesc).text = courseDescription
        findViewById<TextView>(R.id.tvCourseCategory).text = courseCategory
        findViewById<TextView>(R.id.tvCourseMaker).text = "By: ${intent.getStringExtra("makerId")}"
        findViewById<ImageView>(R.id.couresDetail_makerPic).setImageResource(R.drawable.img)

        val backbtn = findViewById<Button>(R.id.courseDetail_back)
        backbtn.setOnClickListener {
            finish()
        }

        val interestbtn = findViewById<Button>(R.id.courseDetail_interest)
        interestbtn.setOnClickListener {
            val userId = getSharedPreferences("USER_DATA", Context.MODE_PRIVATE).getString("USER_ID", null)
            if (userId.isNullOrEmpty()) {
                Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            } else {
                checkAndAddCourseToInterestCollection(courseName, courseDescription, courseCategory, courseMakerId, courseTopics, userId)
            }
        }

        val topicContainer = findViewById<LinearLayout>(R.id.topicContainer)
        topicContainer.removeAllViews()

        courseTopics?.forEach { topic ->
            val topicView = TextView(this).apply {
                val topicText = "Topic: ${topic["title"]}\nDescription: ${topic["description"]}\nVideo Link: ${topic["videoLink"]}"
                text = topicText
                textSize = 24f
                // Use Linkify to automatically recognize the video link and turn it into a clickable link
                Linkify.addLinks(this, Linkify.WEB_URLS)
            }
            topicContainer.addView(topicView)
        }

        
    }

    private fun checkAndAddCourseToInterestCollection(
        name: String?,
        description: String?,
        category: String?,
        maker: String?,
        topics: List<HashMap<String, String>>?,
        userId: String
    ) {
        firestoreRef.collection("users").document(userId).collection("interest")
            .whereEqualTo("name", name)
            .whereEqualTo("maker", maker)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    addCourseToInterestCollection(name, description, category, maker, topics, userId)
                } else {
                    Toast.makeText(this, "Course already in interest", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to check interest: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun addCourseToInterestCollection(
        name: String?,
        description: String?,
        category: String?,
        maker: String?,
        topics: List<HashMap<String, String>>?,
        userId: String
    ) {
        val courseData = hashMapOf(
            "name" to name,
            "description" to description,
            "category" to category,
            "userId" to maker,
            "topics" to topics,
            "userIdFk" to userId
        )

        firestoreRef.collection("users").document(userId).collection("interest").add(courseData)
            .addOnSuccessListener {
                Toast.makeText(this, "Course added to interest", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to add course to interest: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}