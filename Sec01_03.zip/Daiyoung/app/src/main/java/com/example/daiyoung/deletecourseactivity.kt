package com.example.daiyoung

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.daiyoung.ui.home.CourseDetailActivity
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class deletecourseactivity : AppCompatActivity() {

    private lateinit var firestore: FirebaseFirestore
    private var courseId: String? = null
    private lateinit var etCourseName: EditText
    private lateinit var etCourseDescription: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var topicContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deletecourseactivity)

        firestore = FirebaseFirestore.getInstance()
        courseId = intent.getStringExtra("COURSE_ID")

        etCourseName = findViewById(R.id.etCourseName)
        etCourseDescription = findViewById(R.id.etCourseDescription)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        topicContainer = findViewById(R.id.topicContainer)

        findViewById<Button>(R.id.btnSaveChanges).setOnClickListener { updateCourse() }
        findViewById<Button>(R.id.btnAddTopic).setOnClickListener { addNewTopic() }

        loadCourseData()
    }

    private fun loadCourseData() {
        if (courseId == null) {
            Log.e("deletecourseactivity", "courseId is null")
            return
        }

        firestore.collection("courses").document(courseId!!).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val name = document.getString("name")
                    val description = document.getString("description")

                    if (name != null && description != null) {
                        etCourseName.setText(name)
                        etCourseDescription.setText(description)

                        // Load topics data
                        val topics = document["topics"] as? List<Map<String, String>> ?: emptyList()
                        displayTopics(topics)
                    } else {
                        etCourseName.setText("")
                        etCourseDescription.setText("")
                        displayTopics(emptyList())
                    }
                } else {
                    Log.e("deletecourseactivity", "Course document has been deleted or does not exist")
                    etCourseName.setText("")
                    etCourseDescription.setText("")
                    displayTopics(emptyList())
                }
            }
            .addOnFailureListener { e ->
                Log.e("deletecourseactivity", "Error getting document", e)
                etCourseName.setText("")
                etCourseDescription.setText("")
                displayTopics(emptyList())
            }
    }

    private fun displayTopics(topics: List<Map<String, String>>) {
        topicContainer.removeAllViews()
        for (topic in topics) {
            val topicView = LayoutInflater.from(this).inflate(R.layout.item_topicc, topicContainer, false)
            val tvTopicTitle = topicView.findViewById<TextView>(R.id.tvTopicTitle)
            val btnDeleteTopic = topicView.findViewById<Button>(R.id.btnDeleteTopic)

            tvTopicTitle.text = topic["title"]
            btnDeleteTopic.setOnClickListener { deleteTopic(topic) }

            topicContainer.addView(topicView)
        }
    }

    private fun addNewTopic() {
        val newTopic = mapOf("title" to "New Topic", "description" to "Topic description")
        firestore.collection("courses").document(courseId!!).update("topics", FieldValue.arrayUnion(newTopic))
            .addOnSuccessListener { loadCourseData() }
    }

    private fun deleteTopic(topic: Map<String, String>) {
        firestore.collection("courses").document(courseId!!).update("topics", FieldValue.arrayRemove(topic))
            .addOnSuccessListener { loadCourseData() }
    }

    private fun updateCourse() {
        val updatedData: Map<String, Any> = mapOf(
            "courseName" to etCourseName.text.toString(),
            "courseDescription" to etCourseDescription.text.toString()
        )

        firestore.collection("courses").document(courseId!!).update(updatedData)
            .addOnSuccessListener {
                Toast.makeText(this, "Course Updated!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, CourseDetailActivity::class.java).apply {
                    putExtra("COURSE_ID", courseId)
                }
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to update course: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
