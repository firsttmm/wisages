package com.example.daiyoung.ui.home

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.daiyoung.CourseAdapter
import com.example.daiyoung.R
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class Category : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var courseAdapter: CourseAdapter
    private val courses = mutableListOf<Map<String, Any>>()
    private val filteredCourses = mutableListOf<Map<String, Any>>()
    private lateinit var db: FirebaseFirestore
    private lateinit var searchField: EditText
    private lateinit var categorySpinner: Spinner
    private var selectedCategory: String = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            v.setPadding(
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).left,
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).top,
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).right,
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            )
            insets
        }

        db = FirebaseFirestore.getInstance()

        recyclerView = findViewById(R.id.testcourse)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // ส่ง onItemClick ที่ต้องการให้ทำเมื่อคลิก
        courseAdapter = CourseAdapter(filteredCourses) { course ->
            // ทำการเปิด Activity ใหม่เมื่อคลิก
            val intent = Intent(this, CourseDetailActivity::class.java)
            intent.putExtra("COURSE_ID", course["id"] as? String)
            intent.putExtra("COURSE_NAME", course["name"] as? String)
            intent.putExtra("COURSE_DESCRIPTION", course["description"] as? String)
            intent.putExtra("COURSE_CATEGORY", course["category"] as? String)
            startActivity(intent)
        }
        recyclerView.adapter = courseAdapter

        searchField = findViewById(R.id.ettSearch)
        categorySpinner = findViewById(R.id.spinner)

        setupCategorySpinner()
        loadCourses()

        searchField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterCourses(s.toString())
            }
        })
    }

    private fun setupCategorySpinner() {
        val categories = listOf("All", "Life Style", "Technology", "Education", "Cooking")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        categorySpinner.adapter = adapter
        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                selectedCategory = categories[position]
                filterCourses(searchField.text.toString())
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun loadCourses() {
        db.collection("courses")
            .orderBy("name", Query.Direction.ASCENDING)
            .get()
            .addOnSuccessListener { querySnapshot ->
                courses.clear()
                for (document in querySnapshot) {
                    courses.add(document.data)
                }
                filterCourses(searchField.text.toString())
            }
            .addOnFailureListener { e -> Log.e("Firestore Error", "Error loading data", e) }
    }

    private fun filterCourses(searchText: String) {
        filteredCourses.clear()
        for (course in courses) {
            val name = course["name"] as? String ?: ""
            val category = course["category"] as? String ?: ""
            val matchesSearch = name.contains(searchText, ignoreCase = true)
            val matchesCategory = selectedCategory == "All" || selectedCategory == category

            if (matchesSearch && matchesCategory) {
                filteredCourses.add(course)
            }
        }
        courseAdapter.notifyDataSetChanged()
    }
}
