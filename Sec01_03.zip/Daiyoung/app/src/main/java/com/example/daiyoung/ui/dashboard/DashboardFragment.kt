package com.example.daiyoung.ui.dashboard

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.daiyoung.CourseAdapter
import com.example.daiyoung.databinding.FragmentDashboardBinding
import com.example.daiyoung.ui.home.CourseDetailActivity
import com.google.firebase.firestore.FirebaseFirestore

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private lateinit var recyclerView: RecyclerView
    private lateinit var courseAdapter: CourseAdapter
    private val courses = mutableListOf<Map<String, Any>>()

    // This property is only valid between onCreateView and onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root
        recyclerView = binding.interestView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        courseAdapter = CourseAdapter(courses) { course ->
            // Ensure all values are non-null before passing to CourseDetailActivity
            val courseName = course["name"] as? String ?: "Unknown Name"
            val courseDescription = course["description"] as? String ?: "No Description"
            val courseCategory = course["category"] as? String ?: "Uncategorized"
            val courseTopics = course["topics"] as? ArrayList<HashMap<String, String>> ?: arrayListOf()
            val makerId = course["userId"] as? String ?: "Unknown"

            val intent = Intent(requireContext(), CourseDetailActivity::class.java).apply {
                putExtra("name", courseName)
                putExtra("description", courseDescription)
                putExtra("category", courseCategory)
                putExtra("topics", courseTopics)
                putExtra("makerId", makerId)
            }
            startActivity(intent)
        }
        recyclerView.adapter = courseAdapter

        loadCourses()
        return root
    }

    private fun loadCourses() {
        val userId = requireActivity()
            .getSharedPreferences("USER_DATA", Context.MODE_PRIVATE)
            .getString("USER_ID", null)

        if (!userId.isNullOrEmpty()) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(userId)
                .collection("interest")
                .get()
                .addOnSuccessListener { querySnapshot ->
                    courses.clear()
                    for (document in querySnapshot) {
                        // Add course data safely, check if the keys exist
                        val courseData = document.data
                        val courseName = courseData["name"] as? String ?: "Unknown Name"
                        val courseDescription = courseData["description"] as? String ?: "No Description"
                        val courseCategory = courseData["category"] as? String ?: "Uncategorized"
                        val courseTopics = courseData["topics"] as? ArrayList<HashMap<String, String>> ?: arrayListOf()
                        val makerId = courseData["userId"] as? String ?: "Unknown"

                        // Add the safely retrieved course to the list
                        courses.add(mapOf(
                            "name" to courseName,
                            "description" to courseDescription,
                            "category" to courseCategory,
                            "topics" to courseTopics,
                            "userId" to makerId
                        ))
                    }
                    courseAdapter.notifyDataSetChanged()
                }
                .addOnFailureListener { e ->
                    Log.e("Firestore Error", "Error loading data", e)
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
