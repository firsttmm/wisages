package com.example.daiyoung

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Base64
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.util.UUID
import kotlin.toString

class Uploadcourse : AppCompatActivity() {
    private lateinit var etCourseName: EditText
    private lateinit var etDescription: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var btnUploadImage: Button
    private lateinit var btnAddTopic: Button
    private lateinit var btnSave: Button
    private lateinit var imageView: ImageView
    private lateinit var topicContainer: LinearLayout
    private var imageUri: Uri? = null

    private val storageRef = FirebaseStorage.getInstance().reference
    private val firestoreRef = FirebaseFirestore.getInstance()
    private val sharedPreferences by lazy {
        getSharedPreferences(
            "USER_DATA",
            Context.MODE_PRIVATE
        )
    }
    private val categories = arrayOf("Education", "Life Style", "Technology", "Cooking")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_uploadcourse)

        etCourseName = findViewById(R.id.etCourseName)
        etDescription = findViewById(R.id.etDescription)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        btnUploadImage = findViewById(R.id.btnUploadImage)
        btnAddTopic = findViewById(R.id.btnAddTopic)
        btnSave = findViewById(R.id.btnSave)
        imageView = findViewById(R.id.imageView)
        topicContainer = findViewById(R.id.topicContainer)
//        tvTotalDuration = findViewById(R.id.tvTotalDuration) // เพิ่มส่วนแสดงเวลารวม

        spinnerCategory.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)

        btnUploadImage.setOnClickListener { selectImage() }
        btnAddTopic.setOnClickListener { addNewTopicField() }
        btnSave.setOnClickListener { saveCourse() }

        checkUserLoggedIn()
    }

    private fun checkUserLoggedIn() {
        val userId = sharedPreferences.getString("USER_ID", null)

        if (userId.isNullOrEmpty()) {
            Toast.makeText(this, "User not logged in. Redirecting to login...", Toast.LENGTH_SHORT)
                .show()
            startActivity(Intent(this, Login::class.java))
            finish()
        } else {
            Log.d("DEBUG", "USER_ID found: $userId")
        }
    }

    private fun selectImage() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent, 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            imageUri = data?.data
            imageUri?.let { uri ->
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                imageView.setImageBitmap(bitmap)
            }
        }
    }

    private fun uploadImageToFirebaseStorage(imageUri: Uri, onSuccess: (String) -> Unit) {
        val storageRef = FirebaseStorage.getInstance().reference
        val imageRef = storageRef.child("images/${UUID.randomUUID()}.jpg")

        imageRef.putFile(imageUri)
            .addOnSuccessListener {
                imageRef.downloadUrl.addOnSuccessListener { uri ->
                    onSuccess(uri.toString())
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firebase Storage", "Image upload failed: ${e.message}", e)
                Toast.makeText(this, "Image upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }


    private fun addNewTopicField() {
        val newTopicLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 10, 0, 10)
        }

        val newTopicField = EditText(this).apply { hint = "Enter topic" }
        val newDescriptionField = EditText(this).apply { hint = "Enter topic description" }
        val newVideoLinkField = EditText(this).apply { hint = "Enter video link (URL)" }

        newTopicLayout.addView(newTopicField)
        newTopicLayout.addView(newDescriptionField)
        newTopicLayout.addView(newVideoLinkField)
        topicContainer.addView(newTopicLayout)

        val btnRemoveTopic = Button(this).apply {
            text = "Remove"
            setOnClickListener {
                topicContainer.removeView(newTopicLayout)
            }
        }
        newTopicLayout.addView(btnRemoveTopic)
    }

    private fun saveCourse() {
        val userId = sharedPreferences.getString("USER_ID", null)

        if (userId.isNullOrEmpty()) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            return
        }
        val name = etCourseName.text.toString().trim()
        val description = etDescription.text.toString().trim()
        val category = spinnerCategory.selectedItem.toString()
        val topics = mutableListOf<HashMap<String, String>>()

        for (i in 0 until topicContainer.childCount) {
            val layout = topicContainer.getChildAt(i) as LinearLayout
            val topicField = layout.getChildAt(0) as EditText
            val descField = layout.getChildAt(1) as EditText
            val videoLinkField = layout.getChildAt(2) as EditText

            val topicText = topicField.text.toString().trim()
            val descText = descField.text.toString().trim()
            val videoLink = videoLinkField.text.toString().trim()

            if (topicText.isNotEmpty() && descText.isNotEmpty() && videoLink.isNotEmpty()) {
                topics.add(
                    hashMapOf(
                        "title" to topicText,
                        "description" to descText,
                        "videoLink" to videoLink
                    )
                )
            }
        }

        if (name.isEmpty() || description.isEmpty() || topics.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }
        imageUri?.let { uri ->

            val courseData = hashMapOf(
                "name" to name,
                "description" to description,
                "category" to category,
                "topics" to topics,
                "userId" to userId,
                "pictureBase64" to imageUri
            )

            firestoreRef.collection("courses").add(courseData)
                .addOnSuccessListener {
                    Toast.makeText(this, "Course Created", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to create course", Toast.LENGTH_SHORT).show()
                }

            firestoreRef.collection("users").document(userId).collection("courses")
                .add(courseData)
                .addOnSuccessListener {
                    Toast.makeText(this, "Course Created", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to create course", Toast.LENGTH_SHORT).show()
                }
        } ?: run {
            Toast.makeText(this, "Please select an image", Toast.LENGTH_SHORT).show()
        }
    }
}